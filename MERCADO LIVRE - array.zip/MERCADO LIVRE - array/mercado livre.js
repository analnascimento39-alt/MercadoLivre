const produtos = document.getElementById("produtos");

const image = ["vestido.png", "ilia secreto.PNG", "cera ve.PNG", "escova secadora.PNG", "creatina.PNG", "tenis.PNG"];
const azul = ["OFERTA DO DIA"];
const mensagens = ["Vestido Feminino Florido Confortável Modelo FARM Elegante", "Perfume Deo Ilia 50ml Fragâncias Feminino", "Loção Hidratante Sem Perfume 473ml CeraVe", "Britânia Escova Secadora 1300w Cor Preto e Rosa", "Creatina Monohidratada Pura 500g Dark Lab Unidade", "Tênis Olympikus Essential 3 Feminino"];
const preco = ["R$69,90", "R$128,00", "R$92,52", "R$96,68", "R$59,99", "R$219,99"];
const verde = ["Chegará grátis amanhã"];

for (let i = 0; i < image.length; i++) {
    produtos.innerHTML += `
    <div class="conteudo1">
        <div class="espacoImg">
            <img class="img1" src="Imagens/${image[i]}"
        </div>
        <div class="espaco1 azul">
            <p>${azul}</p>
        </div>
        <div class="espaco1">
            <p>${mensagens[i]}</p>
        </div>
        <div class="espaco1 preco">
            <h3>${preco[i]}</h3>
        </div>
        <div class="verdeC">
            <p class="verde">${verde}</p>
            <img src="imagens/full.png">
        </div>
    </div>
   `
}

